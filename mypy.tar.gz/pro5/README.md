Finished all the task 

pick_unop : add UnaryNode public inherite Node, and PosUnaryNode and NegUnaryNode to inherte UnaryNode, and set operator+ and operaotr- for unary operator overload

pick_multop : add DbStarBinaryNode, DbSlashBinaryNode, PercentBinaryNode


pick_PLUS_MINUS : use the given method AddBinaryNode, SubBinaryNode

augassign: such as += : use AddBinaryNode and AsgBinaryNode 

atom: set variable name in NMAE and value in FLOAT and INT

 
def f():
	if 1:
		print 1
	else:
		print 2

f()
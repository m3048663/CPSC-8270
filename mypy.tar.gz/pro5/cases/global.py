x = 3
def f():
	print x

f()
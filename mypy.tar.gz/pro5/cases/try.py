x = 3
def f():
	if 1:
		x = 5
	else:
		t = 10
	def h():
		print x
		print t
	
	h()

f()
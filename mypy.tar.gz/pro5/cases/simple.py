def f():
	x = 5
	print x
f()
